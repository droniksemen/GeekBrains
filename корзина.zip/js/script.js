function init () {
	var button = document.querySelectorAll(".button");
	for(let i=0; i<button.length; i++){
		button[i].onclick = corzina;
	}
}

function corzina(event){
	let eventElement = event.target;
	let buttonNum = eventElement.getAttribute("data-tov");

	if(buttonNum == 1){

		var name = document.getElementById("name1").innerHTML;
		var disc = document.getElementById("disc1").innerHTML;
		var price = document.getElementById("price1").innerHTML;
			price = parseInt(price);

		var corTovName = document.createElement("h4");
		var corTovDisc = document.createElement("p");
		var corTovPrice = document.createElement("p");

		var appDiv = document.getElementById("corzina");
		corTovName.id = "idNameTov";
		corTovDisc.id = "idDiscTov";
		corTovPrice.id = "idPriceTov";

		appDiv.appendChild(corTovName);
		appDiv.appendChild(corTovDisc);
		appDiv.appendChild(corTovPrice);

		var nameTovCor = document.getElementById("idNameTov");
		nameTovCor.innerHTML = name;
		var nameTovCor = document.getElementById("idDiscTov");
		nameTovCor.innerHTML = disc;
		var nameTovCor = document.getElementById("idPriceTov");
		nameTovCor.innerHTML = price;

	}else if (buttonNum == 2) {

		var name2 = document.getElementById("name2").innerHTML;
		var disc2 = document.getElementById("disc2").innerHTML;
		var price2 = document.getElementById("price2").innerHTML;
			price2 = parseInt(price2);

		var corTovName2 = document.createElement("h4");
		var corTovDisc2 = document.createElement("p");
		var corTovPrice2 = document.createElement("p");

		var appDiv = document.getElementById("corzina");
		corTovName2.id = "idNameTov2";
		corTovDisc2.id = "idDiscTov2";
		corTovPrice2.id = "idPriceTov2";

		appDiv.appendChild(corTovName2);
		appDiv.appendChild(corTovDisc2);
		appDiv.appendChild(corTovPrice2);

		var nameTovCor2 = document.getElementById("idNameTov2");
		nameTovCor2.innerHTML = name2;
		var nameTovCor2 = document.getElementById("idDiscTov2");
		nameTovCor2.innerHTML = disc2;
		var nameTovCor2 = document.getElementById("idPriceTov2");
		nameTovCor2.innerHTML = price2;

	}else if (buttonNum == 3) {

		var name3 = document.getElementById("name3").innerHTML;
		var disc3 = document.getElementById("disc3").innerHTML;
		var price3 = document.getElementById("price3").innerHTML;
			price3 = parseInt(price3);

		var corTovName3 = document.createElement("h4");
		var corTovDisc3 = document.createElement("p");
		var corTovPrice3 = document.createElement("p");

		var appDiv = document.getElementById("corzina");
		corTovName3.id = "idNameTov3";
		corTovDisc3.id = "idDiscTov3";
		corTovPrice3.id = "idPriceTov3";

		appDiv.appendChild(corTovName3);
		appDiv.appendChild(corTovDisc3);
		appDiv.appendChild(corTovPrice3);

		var nameTovCor3 = document.getElementById("idNameTov3");
		nameTovCor3.innerHTML = name3;
		var nameTovCor3 = document.getElementById("idDiscTov3");
		nameTovCor3.innerHTML = disc3;
		var nameTovCor3 = document.getElementById("idPriceTov3");
		nameTovCor3.innerHTML = price3;

	}else if (buttonNum == 4) {

		var name4 = document.getElementById("name4").innerHTML;
		var disc4 = document.getElementById("disc4").innerHTML;
		var price4 = document.getElementById("price4").innerHTML;
			price4 = parseInt(price4);


		var corTovName4 = document.createElement("h4");
		var corTovDisc4 = document.createElement("p");
		var corTovPrice4 = document.createElement("p");

		var appDiv = document.getElementById("corzina");
		corTovName4.id = "idNameTov4";
		corTovDisc4.id = "idDiscTov4";
		corTovPrice4.id = "idPriceTov4";

		appDiv.appendChild(corTovName4);
		appDiv.appendChild(corTovDisc4);
		appDiv.appendChild(corTovPrice4);

		var nameTovCor4 = document.getElementById("idNameTov4");
		nameTovCor4.innerHTML = name4;
		var nameTovCor4 = document.getElementById("idDiscTov4");
		nameTovCor4.innerHTML = disc4;
		var nameTovCor4 = document.getElementById("idPriceTov4");
		nameTovCor4.innerHTML = price4;

	}
	
}

window.onload = init;